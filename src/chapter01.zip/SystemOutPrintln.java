package chapter01;

public class SystemOutPrintln {
	public static void main(String[] args) {
		/* 주석 
		 * // - 한줄 주석
		 * - 컴파일의 대상에서 제외
		 * - 메모기능, 아무런 실행이 되지 않는다
		 * 
		 * 컴파일러
		 * - 자바 언어를 어셈블리어로 번역
		 * - 어셈블리어 -> cpu를 통해 실행
		 * - 자바 파일(소스 파일) -> 컴파일러가 main 메소드(함수) 찾아서
		 * 위에서 아래로 순차적으로 한문장씩 실행
		 * 
		 * () 소괄호, {} 중괄호, []대괄호
		 * 자바는 기본 단위가 class 모든 코드는 class {} 안에 작성
		 */
		System.out.println("주석과 컴파일러");
		// 유지 보수성과 확장성이 좋아야 된다 !!
		
		/*
		 * 들여 쓰기 - tab
		 * class {} 포함 된다
		 * 하위 코드 - tab으로 들여쓰기 해서 정렬
		 * 영역을 나타 낼때 {} 중괄호 사용
		 */
	}
}
