/*
 * 파일이름 : SystemOutPrintln02
 * 작성자 : 구형준
 * 작성일 : 2024년 3월 12일
 * 목적 : System.Out.println 메소드의 기능 테스트
 */
package chapter01;


public class SystemOutPrintln02 {
	public static void main(String[] args) {
		System.out.println("꾸준히 코드 작성하기 !!"); // 다음은 간단한 문장 출력
		
		System.out.println(3.15);
		System.out.println("3+5 = " + 8);
		System.out.println(3.15 + "는 실수입니다.");
		System.out.println("3+5" + "의 연산 결과는 8입니다.");
		System.out.println(3+5);
	}
}
