package chapter01;

public class FirstCode {
	public static void main(String[] args) {
		//글자 크기 조절 - control + (+,-)
		//들여 쓰기 tab - 스페이스 4개 정도의 공간
		System.out.println("Hello World!");
	}
}
