
public class BasicTask02 {
	public static void main(String[] args) {
		System.out.println(9);
		System.out.println(3.15);
		System.out.println("3+6 = " + 9);
		System.out.println(3.15 + "는 실수입니다.");
		System.out.println("3+6" + "의 연산 결과는 9입니다.");
		System.out.println(3+6);
		
	}
}
