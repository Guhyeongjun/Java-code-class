
public class BasicTask05 {
	public static void main(String[] args) {
		System.out.println(12);
		System.out.println(3.15);
		System.out.println("3+9 = " + 12);
		System.out.println(3.15 + "는 실수입니다.");
		System.out.println("3+9" + "의 연산 결과는 12입니다.");
		System.out.println(3+9);
	}
}
