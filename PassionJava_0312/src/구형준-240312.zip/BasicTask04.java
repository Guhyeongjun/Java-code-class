
public class BasicTask04 {
	public static void main(String[] args) {
		System.out.println(11);
		System.out.println(3.15);
		System.out.println("3+8 = " + 11);
		System.out.println(3.15 + "는 실수입니다.");
		System.out.println("3+8" + "의 연산 결과는 11입니다.");
		System.out.println(3+8);
	}
}
