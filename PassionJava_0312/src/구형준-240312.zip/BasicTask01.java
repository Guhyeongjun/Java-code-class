
public class BasicTask01 {
	public static void main(String[] args) {
		System.out.println(7);
		System.out.println(3.15);
		
	}
}
