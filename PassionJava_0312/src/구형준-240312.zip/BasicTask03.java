
public class BasicTask03 {
	public static void main(String[] args) {
		System.out.println(10);
		System.out.println(3.15);
		System.out.println("3+7 = " + 10);
		System.out.println(3.15 + "는 실수입니다.");
		System.out.println("3+7" + "의 연산 결과는 10입니다.");
		System.out.println(3+7);
	}
}
