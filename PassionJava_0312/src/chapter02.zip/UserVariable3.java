package chapter02;

public class UserVariable3 {
	public static void main(String[] args) {
		/*
		 * 정사각형의 둘레를 구하는 코드 작성
		 * 한변 * 4
		 * 한변의 길이는 마음데로 정하세요
		 * 한변의 길이가 7
		 */
		System.out.println(7*4); // 80점
		int squareSide = 7;
		System.out.println(squareSide * 4); // 100점
	}
}
